import pylion
from pylion import lammps
from .sion import *

__version__ = "1.0.5"
__author__ = """Artem Podlesnyy"""
__email__ = 'a.podlesnyy@rqc.ru'